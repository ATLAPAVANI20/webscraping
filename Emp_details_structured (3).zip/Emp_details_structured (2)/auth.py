import http.client
import json
import os
from dotenv import load_dotenv

def get_aceess_token():

    load_dotenv()

    # Access the environment variables
    Client_ID = os.getenv("client_id")
    Client_Secret = os.getenv("client_secret")
    API_Key = os.getenv("api_key")

    conn = http.client.HTTPSConnection("login.keka.com")

    payload = f'grant_type=kekaapi&scope=kekaapi&client_id={Client_ID}&client_secret={Client_Secret}&api_key={API_Key}'

    headers = {

      'Content-Type': 'application/x-www-form-urlencoded'

    }

    conn.request("POST", "/connect/token", payload, headers)

    res = conn.getresponse()

    data = res.read()
    # Parse the string as a JSON object
    data = json.loads(data.decode("utf-8"))

    # Access the 'access_token' value
    access_token = data['access_token']

    return access_token






