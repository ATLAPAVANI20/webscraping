import requests
from auth import get_aceess_token
from mapping import index_data
import time

#This class indexes employee data from a specific API URL
class EmployeeDataIndexer:
    
    # Constructor method that initializes the object with necessary attributes.
    def __init__(self):
        self.access_token = get_aceess_token()
        self.headers = {
            "accept": "application/json",
            "authorization": f"Bearer {self.access_token}"
        }

    # Get the value associated with the given key from the dictionary.
    def get_attribute_value(self, dictionary, key):
        if key in dictionary:
            return dictionary[key]
        else:
            return "Key not found"

    # This function is used to replace the numeric values with the particular string values.
    def key_value(self, key, dict, employee_details):
        if key in employee_details:
            employee_details[key] = self.get_attribute_value(dict, employee_details[key])
        return employee_details[key]

    # This function is used to retrive all data of employees from the URL
    def get_all_pages(self, url):
        print("--->Fetching Employees Data Started!<---")
        try:
            groups=[]
            customFields=[]
            educationDetails=[]
            experienceDetails=[]

            response = requests.get(url, headers=self.headers)
            data=response.json()
            totalPages=data['totalPages']
            current_page=data['pageNumber']
            total_counts=0

            # This while loop will rotate till last page and it will indexed all employees data.
            while current_page<=totalPages:
                response = requests.get(url, headers=self.headers)
                data1=response.json()
                Employee_Info=['employeeNumber','firstName','middleName','lastName','displayName','email','jobTitle','secondaryJobTitle','reportsTo','timeType','workerType','isProfileComplete','gender','joiningDate','professionalSummary','dateOfBirth','resignationSubmittedDate','exitDate','employmentStatus','accountStatus','invitationStatus','exitStatus','exitType','exitReason','workPhone','homePhone','mobilePhone','bloodGroup','attendanceNumber','probationEndDate','currentAddress','permanentAddress','educationDetails','experienceDetails','customFields','groups','leavePlanInfo','bandInfo','payGradeInfo','shiftPolicyInfo','weeklyOffPolicyInfo','captureSchemeInfo','trackingPolicyInfo','expensePolicyInfo','overtimePolicyInfo','id']
                SystemGroupType={0: 'None', 1:'BusinessUnit', 2: 'Department', 3: 'OrgLocation', 4: 'CostCenter', 5: 'Paygroup', 6: 'ProjectTeam', 7:'Team', 8:'ClientTeam', 9:'Segment'}
                
                # Final_data is list which contains 100 employees details for current page.
                final_data=data1.get("data", [])
                total_counts=total_counts+len(final_data)

                for i in range(len(final_data)):
                    employee_details={}
                    for info in Employee_Info:

                        if isinstance(final_data[i][info], dict):

                            if info=='reportsTo':
                                reportsTo={}
                                for key, value in final_data[i][info].items():
                                    reportsTo["Reportingmanager"+"_"+key]=value
                                employee_details['reportsTo']=reportsTo
                            
                            elif info=='currentAddress':
                                currentAddress={}
                                for key, value in final_data[i][info].items():
                                    if key in ['addressLine1','addressLine2']:
                                        number=key[7:]
                                        currentAddress[info+"_"+number]=value
                                    else:
                                        currentAddress[info+"_"+key]=value
                                employee_details['currentAdress']=currentAddress

                            elif info=='permanentAddress':
                                permanentAddress={}
                                for key, value in final_data[i][info].items():
                                    if key in ['addressLine1','addressLine2']:
                                        number=key[7:]
                                        permanentAddress[info+number]=value
                                    else:
                                        permanentAddress[info+"_"+key]=value
                                employee_details['permanentAddress']=permanentAddress

                            elif info=='leavePlanInfo':
                                leavePlanInfo={}
                                for key, value in final_data[i][info].items():
                                    if key=='identifier':
                                        leavePlanInfo[info+"_"+key]=value
                                    else:
                                        leavePlanInfo[info]=value
                                employee_details['leavePlanInfo']=leavePlanInfo


                            elif info=='payGradeInfo':
                                payGradeInfo={}
                                for key, value in final_data[i][info].items():
                                    if key=='identifier':
                                        payGradeInfo[info+"_"+key]=value
                                    else:
                                        payGradeInfo[info]=value
                                employee_details['payGradeInfo']=payGradeInfo


                            elif info=='jobTitle':
                                jobTitle={}
                                for key, value in final_data[i][info].items():
                                    if key=='identifier':
                                        jobTitle[info+"_"+key]=value
                                    else:
                                        jobTitle[info]=value
                                employee_details['jobTitle']=jobTitle


                            elif info=='shiftPolicyInfo':
                                shiftPolicyInfo={}
                                for key, value in final_data[i][info].items():
                                    if key=='identifier':
                                        shiftPolicyInfo[info+"_"+key]=value
                                    else:
                                        shiftPolicyInfo[info]=value
                                employee_details['shiftPolicyInfo']=shiftPolicyInfo

                            elif info=='weeklyOffPolicyInfo':
                                weeklyOffPolicyInfo={}
                                for key, value in final_data[i][info].items():
                                    if key=='identifier':
                                        weeklyOffPolicyInfo[info+"_"+key]=value
                                    else:
                                        weeklyOffPolicyInfo[info]=value
                                employee_details['weeklyOffPolicyInfo']=weeklyOffPolicyInfo

                            elif info=='captureSchemeInfo':
                                captureSchemeInfo={}
                                for key, value in final_data[i][info].items():
                                    if key=='identifier':
                                        captureSchemeInfo[info+"_"+key]=value
                                    else:
                                        captureSchemeInfo[info]=value
                                employee_details['captureSchemeInfo']=captureSchemeInfo


                            elif info=='trackingPolicyInfo':
                                trackingPolicyInfo={}
                                for key, value in final_data[i][info].items():
                                    if key=='identifier':
                                        trackingPolicyInfo[info+"_"+key]=value
                                    else:
                                        trackingPolicyInfo[info]=value
                                employee_details['trackingPolicyInfo']=trackingPolicyInfo

                            elif info=='expensePolicyInfo':
                                expensePolicyInfo={}
                                for key, value in final_data[i][info].items():
                                    if key=='identifier':
                                        expensePolicyInfo[info+"_"+key]=value
                                    else:
                                        expensePolicyInfo[info]=value
                                employee_details['expensePolicyInfo']=expensePolicyInfo

                                            
                        elif isinstance(final_data[i][info], list):
                            count=1
                            
                            for dictionary in range(len(final_data[i][info])):

                                if dictionary in [17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,58]:
                                    pass

                                elif info=='customFields':
                                    title=final_data[i][info][dictionary]['title']
                                    if title=='Applicant ID':
                                        title=title.split(" ")[0]
                                    title=title.replace('.','')
                                    value=final_data[i][info][dictionary]['value']
                                    id=final_data[i][info][dictionary]['id']

                                    final_data[i][info][dictionary].clear()
                                    
                                    final_data[i][info][dictionary][title+"_"+'id']=id
                                    final_data[i][info][dictionary][title]=value

                                    customFields.append(final_data[i][info][dictionary])
                                

                                elif info=='groups':
                                    GroupType_number=final_data[i][info][dictionary]['groupType']
                                    GroupType=SystemGroupType[GroupType_number]
                                    
                                    id=final_data[i][info][dictionary]['id']
                                    title=final_data[i][info][dictionary]['title']

                                    final_data[i][info][dictionary].clear()

                                    final_data[i][info][dictionary][GroupType+"_"+'id']=id
                                    final_data[i][info][dictionary][GroupType]=title

                                    groups.append(final_data[i][info][dictionary])
                                    
                                   
                                elif info=='educationDetails':
                                    if all(final_data[i][info][dictionary].get(field) is not None for field in ['degree', 'branch', 'yearOfJoining', 'yearOfCompletion', 'university']):

                                        Edu_degree=final_data[i][info][dictionary]['degree']
                                        try:
                                            if final_data[i][info][dictionary]['customFields'] == []:
                                                final_data[i][info][dictionary].pop('customFields', None)
                                        except:
                                            pass
                                        new_data={}
                                        for key,value in final_data[i][info][dictionary].items():
                                            if key!='degree':
                                                new_data[Edu_degree+"_"+key]=value
                                            else:
                                                new_data[key]=value

                                        educationDetails.append(new_data)
                                        count = count+1
                                        

                                elif info=='experienceDetails':
                                    try:
                                        if final_data[i][info][dictionary]['customFields'] == []:
                                            final_data[i][info][dictionary].pop('customFields', None)
                                    except:
                                        pass
                                    new_data={}
                                    for key, value in final_data[i][info][dictionary].items():
                                        
                                        temp="company"
                                        if key=='companyName':
                                            new_data[f"{key}{count}"]=value
                                        else:
                                            new_data[f"{temp}{count}_{key}"]=value
                                            
                                    experienceDetails.append(new_data)
                                    count+=1

                                employee_details['educationDetails']=educationDetails
                                employee_details['experienceDetails']=experienceDetails
                                employee_details['customFields']=customFields
                                employee_details['groups']=groups
                                

                        else:
                            if info=='id':
                                employee_details["emp"+"_"+info]=final_data[i][info]
                            else:
                                employee_details[info]=final_data[i][info]


                    # Initialized the dictionary for replacing numeric values with string.
                    timetype = {0: 'None', 1: 'FullTime', 2: 'PartTIme'}
                    workertype = {0: 'None', 1: 'Permanent', 2: 'Contract'}
                    Gender = {0: 'NotSpecified', 1: 'Male', 2: 'Female', 3: 'Nonbinary'}
                    EmploymentStatus = {0: 'Working', 1: 'Relieved'}
                    AccountStatus = {0: 'NotRegistered', 1: 'Registered', 2: 'Disabled'}
                    InvitationStatus = {0: 'NotInvited', 1: 'Invited'}
                    ExitStatus = {0: 'None', 1: 'Initiated', 2: 'Completed'}
                    ExitType = {0: 'None', 1: 'Employee Resignation', 2: 'Company Action', 3: 'Other'}
                    BloodGroup = {0: 'Not Available', 1: 'A Positive', 2: 'A- (A Negative)', 3: 'B+ (B Positive)', 4: 'B- (B Negative)', 5: 'AB+ (AB Positive)', 6: 'AB- (AB Negative)', 7: 'O+ (O Positive)', 8: 'O- (O Negative)', 9: 'B+ (B Positive)', 
                                    10: 'A2+ (A2 Positive)', 11: 'A1+ (A1 Positive)', 12: 'A1B- (A1B Negative)', 13: 'A1B+ (A1B Positive)', 14: 'A2- (A2 Negative)', 15: 'A2B+ (A2B Positive)', 16:'A2B- (A2B Negative)', 17: 'B1+ (B1 Positive)'}
                   
                    # Calling key_value function for replacing numeric values.
                    employee_details['timeType'] = self.key_value('timeType', timetype, employee_details)
                    employee_details['workerType'] = self.key_value('workerType', workertype, employee_details)
                    employee_details['gender'] = self.key_value('gender', Gender, employee_details)
                    employee_details['employmentStatus'] = self.key_value('employmentStatus', EmploymentStatus, employee_details)
                    employee_details['accountStatus'] = self.key_value('accountStatus', AccountStatus, employee_details)
                    employee_details['invitationStatus'] = self.key_value('invitationStatus', InvitationStatus, employee_details)
                    employee_details['exitStatus'] = self.key_value('exitStatus', ExitStatus, employee_details)
                    employee_details['exitType'] = self.key_value('exitType', ExitType, employee_details)
                    employee_details['bloodGroup'] = self.key_value('bloodGroup', BloodGroup, employee_details)
                    

                   #Calling index data function for indexing the employee details.
                    index_data(employee_details)

                    #Removing the past employee details from list.
                    educationDetails.clear()
                    groups.clear()
                    customFields.clear()
                    experienceDetails.clear()

                current_page+=1
                url=data1['nextPage']
            time.sleep(0.3)
            # return emp_info
            return f"{total_counts} employees data are indexed..."

        except requests.exceptions.RequestException as req_err:
            return f"Request Error: {req_err}"
        except (ValueError, KeyError) as json_err:
            return f"JSON Parsing Error: {json_err}"
        except Exception as err:
            return f"An error occurred: {err}"

    def index_employee_data(self, url):
        all_employee_data = self.get_all_pages(url)
        return all_employee_data

if __name__ == "__main__":
    url = "https://mouritech.keka.com/api/v1/hris/employees?inProbation=false&inNoticePeriod=false"
    # url="https://mouritech.keka.com/api/v1/hris/employees?employeeNumbers=804875&inProbation=false&inNoticePeriod=false"

    start = time.time()
    # Creating the object of EmployeeDataIndexer Class and calling index_employee_data function.
    employee_indexer = EmployeeDataIndexer()
    all_employee_data = employee_indexer.index_employee_data(url)
    print(all_employee_data)

    print("\n--->Employess Data Fetched Successfully!<---")
    print("---> Total Time Time - ", round(time.time()-start, 2), " seconds!<---")
