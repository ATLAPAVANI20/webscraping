from elasticsearch import Elasticsearch
import logging

logging.basicConfig(level=logging.DEBUG)
# Configure Elasticsearch client
es = Elasticsearch(['http://localhost:9200'])

index_name = "kek2"  # Replace with your desired index name

# Define dynamic mapping
mapping =  {
    "settings": {
        "index.mapping.total_fields.limit": 10000
    },
    "mappings": {
        "dynamic_templates": [
            {
                "strings_as_keywords": {
                    "path_match": "customFields.*",
                    "mapping": {
                        "type": "keyword"
                    }
                }
            },
            {
                "nested_objects": {
                    "path_match": "*.id",
                    "mapping": {
                        "type": "keyword"
                    }
                }
            },
            {
                "integers_as_longs": {
                    "path_match": "integerFields.*",
                    "mapping": {
                        "type": "integer"
                    }
                }
            },
            {
                "dates_as_date": {
                    "path_match": "dateFields.*",
                    "mapping": {
                        "type": "date"
                    }
                }
            },
            {
                "floats_as_floats": {
                    "path_match": "floatFields.*",
                    "mapping": {
                        "type": "float"
                    }
                }
            },
            {
                "texts_as_text": {
                    "path_match": "textFields.*",
                    "mapping": {
                        "type": "text"
                    }
                }
            },
            {
                "booleans_as_booleans": {
                    "path_match": "booleanFields.*",
                    "mapping": {
                        "type": "boolean"
                    }
                }
            },
            {
                "arrays_as_arrays": {
                    "path_match": "arrayFields.*",
                    "mapping": {
                        "type": "nested",
                        "properties": {
                            "value": {
                                "type": "keyword"
                            }
                        }
                    }
                }
            }
            # // Add more dynamic templates for other field types as needed
        ]
    }
}



def index_data(dic):
    if not es.indices.exists(index=index_name):
        es.indices.create(index=index_name, body=mapping)

    # Extract the unique identifier (emp_id) from the data dictionary
    emp_id = dic.get("emp_id")

    if emp_id:
        # Check if the document already exists based on emp_id
        existing_document = es.get(index=index_name, id=emp_id, ignore=[404])
        if existing_document["found"]:
            # Update the existing document
            es.index(index=index_name, id=emp_id, body=dic)
        else:
            # Index the new data
            es.index(index=index_name, id=emp_id, body=dic)
    else:
        # If emp_id is missing, log an error or handle accordingly
        logging.error("Missing emp_id in data dictionary")







    


   