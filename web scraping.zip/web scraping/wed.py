import requests
from bs4 import BeautifulSoup
import pandas as pd

url ="https://www.wedmegood.com/vendors/delhi-ncr/planners/"

res = requests.get(url).content
# print(res)

soup =BeautifulSoup(res,"html.parser")

infos = soup.find('div',class_='vendor-info')
c=1
planners=[]
ratings=[]

for info in infos:
    planner =info.find('a',class_='vendor-detail')
    # print(c,'-',planner.text.strip())
    planners.append(planner.text.strip())

    rating = info.find('span',class_='StarRating')
    # print(rating.strip())
    ratings.append(rating.text.strip())
    # print('')

    c+=1
data ={'planner':planner,'ratings':ratings}    

df=pd.Datafram(data=data)
print(df)

df.to_csv('wedding.csv',index=False)