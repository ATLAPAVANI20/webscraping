#image and link

import requests
from bs4 import BeautifulSoup

url="https://www.indiatoday.in/"

res = requests.get(url).content
soup =  BeautifulSoup(res,'html.parser')

images = soup.find_all('img')
for img in images:
     print(img['src'])

links = soup.find_all('a')
for link in links:
    print(link['href'])
