import requests
from bs4 import BeautifulSoup

for i in range(1,20):
    # url ="https://quotes.toscrape.com/page/"+str(i)+'/'
    # url ="https://www.flipkart.com/mobiles/"+str(i)+'/'
    url='https://www.flipkart.com/mobiles/mi~brand/pr?sid=tyy%2C4io&otracker=nmenu_sub_Electronics_0_Mi&page='+str(i)+'/'


    res = requests.get(url).content
    # print(res)
    soup =BeautifulSoup(res,"html.parser")
    # quotes = soup.find_all('span',class_='text')
    # print(quotes)
    quotes = soup.find_all('div',class_='_3wU53n')
    # print(quotes)

    for quotes in quotes:
        print(quotes.text)
    print()
    print("page_id:",i)    
