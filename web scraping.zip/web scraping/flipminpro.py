import requests
from bs4 import BeautifulSoup
keyword="phone under 10000"

url ="https://www.flipkart.com/search?q="+keyword+""
res = requests.get(url).content
soup =  BeautifulSoup(res,'html.parser')
# print(soup.prettify)
###verticle data
title =soup.find_all('div',class_="_3wu5n")
c=1
for item in title:
    print(c,'--',item.title)
    c+=1
print(title)


###horizonal data

price =soup.find_all('a',class_='_30jeq3 _16Jk6d')
c=1
for item in price:
    print(c,'--',item.title)
    c+=1
# print(price)
# print('price:',price.text)


