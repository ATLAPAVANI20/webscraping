import requests
from bs4 import BeautifulSoup
import json
url ="https://www.flipkart.com/leotude-printed-men-round-neck-navy-blue-t-shirt/p/itmb3879b1adffdc?pid=TSHGH8HJWWPHUREB&lid=LSTTSHGH8HJWWPHUREBR1MR0U&marketplace=FLIPKART&store=clo%2Fash%2Fank%2Fedy&srno=b_1_2&otracker=browse&fm=neo%2Fmerchandising&iid=en_JpZ%2B3X9Qlq5OOIvfyb%2FsDSM6b1fDppO1%2BjUuSUfy8KfoT3IBi3%2BIHqLJVGcH5fWbGsMW4UGjTVgGNpcJoRjeUg%3D%3D&ppt=pp&ppn=pp&ssid=isd3hbhf7k0000001673552211998/"

#find all links'

res = requests.get(url).content
soup =  BeautifulSoup(res,'html.parser')
# print(soup.prettify)
title =soup.find('span',class_="B_NuCI")
print('title:',title.text)
price =soup.find('div',class_='_30jeq3 _16Jk6d')
print('price:',price.text)

data_str = soup.find('script',id="jsonLD").text
# print(data_str)
context = json.loads(data_str)
# print(data_str)
# # print(len(context))
print(context[0])
# print('review_count:',context[0]['aggregateRating']['reviewCount'])
# print('Rating:',context[0]['aggregateRating']['reviewValue'])