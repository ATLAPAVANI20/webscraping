import requests
from bs4 import BeautifulSoup
'''
url = 'https://www.google.com/'

res = requests.get(url).content

# print(res)

soup =  BeautifulSoup(res,features ='lxml')
# print(soup.prettify()) #format html will change 

print(soup.a)#a <a in html>
print(soup.a.text)

print(soup.a.titletext )

print(soup.footer)
print(soup.scripts)
'''
url ="https://www.indiatoday.in/"

#find all links'

res = requests.get(url).content
soup = BeautifulSoup( res,"html")
# print(soup.prettify)

# a_tag = soup.find_all('a')
# print(a_tag)


# #all link
# for link in a_tag:
#     print(link.text)
    
#find sim link    

for h2_tag in soup.find_all('h3'):
    # print(h2_tag)
    for a_tag in h2_tag.find_all('a'):
        print(a_tag.text)
        print(url+a_tag.get('href'))
        
    # print(h2_tag.a.get("href"))